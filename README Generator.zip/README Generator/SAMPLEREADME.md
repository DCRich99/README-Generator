# Professional Readme Generator

  ## Licensing:
  [![license](https://img.shields.io/badge/license-MIT-blue)](https://shields.io)

  ## Table of Contents 
  - [Description](#description)
  - [Installation](#installation)
  - [Usage](#usage)
  - [Contribution](#contribution)
  - [Testing](#testing)
  - [Additional Info](#additional-info)

  ## Description:
  Easily creating README.MD's in a jippy

  ## Installation:
  download it through github

  ## Usage:
  run it by typing 'node index.js'

  ## License:
  MIT

  ## Contribution:
  N/A

  ## Testing:
  N/A

  ## Additional Info:
  - Github: [jwilferd10](https://github.com/jwilferd10)
  - Email: jwilferd10@yahoo.com 